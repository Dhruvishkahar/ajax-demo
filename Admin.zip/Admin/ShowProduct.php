<!DOCTYPE html>
<html>
  
<!-- Mirrored from demo.bootstrapious.com/dark-admin-premium/1-4-4/tables-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Oct 2018 11:04:23 GMT -->
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dark Bootstrap Admin by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom" >ShowSubCategory</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item active">ShowProduct</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="block">
              
              <div class="block-body">
                
                <div class="table-responsive">
                  <table id="datatable1" style="width: 100%;" class="table">
                    <thead align="center">
                      <tr>
                        <th>Id</th>
                        <th>Image</th>
                        <th>Category</th>
                        <th>Sub-Category</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Descripation</th>
                        <th>Update</th>
                        <th>Delete</th>
                        
                      </tr>
                    </thead>
                    <?php
                    foreach ($all_product as $key => $value) {?>
                      <tbody align="center">
                        <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->p_id;?></a></td>
                     <td><img src="<?php echo base_url()?>uploads/<?php echo $value->p_image;?>" height="50px; "></td>
                     <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->cat_name;?></a></td>
                     <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->sub_name;?></a></td>
                     <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->p_name;?></a></td>
                     <td><a href="javascript: return(void);" class="text-muted">₹<?php echo $value->p_price;?></a></td>
                     <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->p_details;?></a></td>
                     <td><a href="<?php echo base_url()?>Admin/update/<?php echo $value->p_id;?>" class="btn btn-default btn-flat">Edit</a></td>
                     <td><a href="<?php echo base_url()?>Admin/delete/<?php echo $value->p_id;?>" class="btn btn-default btn-flat">Delete</a></td>
                     

                   </tbody>
                  <?php   }
                    ?>
                   
                    
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
        
      </div>
    </div>
    <?php $this->load->view('Admin/Comman/Footer');?>
    
    <!-- JavaScript files-->
    <?php $this->load->View('Admin/Comman/script');?>
  </body>

<!-- Mirrored from demo.bootstrapious.com/dark-admin-premium/1-4-4/tables-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 26 Oct 2018 11:04:24 GMT -->
</html>
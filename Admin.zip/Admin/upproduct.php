<!DOCTYPE html>
<html>
<head>
	<title>Edit product</title>
	<?php $this->load->view('Admin/Comman/css');?>
</head>
<body>
	<?php $this->load->view('Admin/Comman/header');?>
	<div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Home</h2>
          </div>
        </div>
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item active">update-product</li>
          </ul>
        </div>
        <section class="no-padding-top" style="margin-left: 200px; margin-top:50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-8" >
                <div class="block">
                  <?php
                    foreach ($all_product as $key => $value) {?>
                    <div class="block-body">
                    <form method="POST" action="<?php echo base_url()?>Admin/updatedata" enctype="mutipart/form-data">
                  
                      <div class="form-group">       
                        <label class="form-control-label" style="color:white;font-weight: bold;"><strong>Sub-id</strong></label>
                       <input id="category" readonly  type="text" name="p_id" required data-msg="Please enter your category" class="form-control" placeholder="Enter the Category" value="<?php echo $value->p_id;?>">
                      </div> 
					</div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-weight: bold;"><strong>category</strong></label>
                        <select name="cat_name"  class="form-control">
                        	<?php
                        		foreach ($cat as $res) {?>
                        			<option  <?php if ($res->cat_id == $value->category_fk) {
                        				echo "selected";
                        			}?>  value="<?php echo $res->cat_id;?>"><?php echo $res->cat_name;?></option>
                        		<?php  }

                        	?>
                        </select>
                      </div>
                      <div class="form-group">
                      	<label class="form-control-label" style="color: white;font-weight: bold;">Sub_Category</label>
                      		<select name="sub_name" class="form-control">
                      			<?php  
                      				foreach ($sub as $item) {?>
                      					<option  <?php if ($item->sub_id == $value->sub_cat_fk) {
                      					echo "selected";
                      					}?>  value="<?php echo  $item->sub_id;?>"><?php echo $item->sub_name;?></option>
                      			<?php  	}
                      			?>
                      		</select>
                      </div>
                      <div class="form-group">
                      	<label class="form-control-label" style="font-weight: bold;color:white;">Product-name</label>
                      	<input type="text" name="p_name" value="<?php echo $value->p_name;?>" class="form-control">
                      	
                      </div>
                      <div class="form-group">
                      	<label class="form-control-label"  style="font-weight: bold;color: white;">product_price</label>
                      	<input type="text" name="p_price" value="<?php echo $value->p_price;?>" class="form-control">
                      </div>

                      





                      <div class="form-group">
                      	<label class="form-control-label"  style="font-weight: bold;color: white;">product_Descripation</label>
                      	<textarea type="text" name="p_details" required data-msg="pelase the Enter the Product descripation"  class="form-control" ><?php echo $value->p_details;?></textarea> 
                      </div>
                    	<div class="form-group">
						            <label class="form-control-label" style="font-weight: bold;color: white;">Current-image</label>
						                <img src="<?php echo base_url()?>/uploads/<?php echo $value->p_image;?>" height="70" width="70">
						                <input type="text" readonly name="old_image" value="<?php echo $value->p_image;?>" class="col-lg-7" >                    		
                    	</div>
                    	<div class="form-group">
                    		<label class="form-control-label" style="font-weight: bold;color: white;">Change-image</label>
                    		<input type="file" name="image" class="form-control">
                    		
                    	</div>

                      <input type="submit" name="update-product" value="update-product" class="btn btn-primary">

                          
                              
                             





                      
                    </form>
                  </div>
                 <?php    }


                  ?>
                </div>
          </div>
      </div>
  </div>
</section>
    </div>
</div>

</body>
</html>
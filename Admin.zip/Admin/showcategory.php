<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fashion Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
     <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <!-- Page Header-->
        <div class="page-header no-margin-bottom">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">ShowCategory</h2>
          </div>
        </div>
        <!-- Breadcrumb-->
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index-2.html">Home</a></li>
            <li class="breadcrumb-item active">ShowCategory</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="block">
              
              <div class="block-body">
                
                <div class="table-responsive">
                  <table id="datatable1" style="width: 90%;" class="table">
                    <thead align="center" style="padding-left: 90px;">
                      <tr>
                        <th>Cat_id</th>
                        <th>Cat_Name</th>
                        <th>Update</th>
                        <th>Delete</th>
                        
                      </tr>
                    </thead>
                    <?php

                      foreach ($all_category as $key => $value) {?>
                       <tbody align="center">
                      <tr>
                        <td><?php echo $value->cat_id;?></td>
                        <td><a href="javascript: return(void);" class="text-muted"><?php echo $value->cat_name;?></a></td>
                        <td align="center"><a href="<?php echo base_url()?>Admin/updatecategory/<?php echo $value->cat_id;?>"><i class="fa fa-edit" style="font-size:24px;color:yellow;"></i></a></td>
              <td align="center"><a href="<?php echo base_url()?>Admin/deletecategory/<?php echo $value->cat_id;?>"><i class="fa fa-trash-o" style="font-size:24px;color:yellow"></i></a></td>
                        
                      </tr>
                      
                  
                    </tbody>
            <?php          }
                    ?>
                    
                  </table>
                </div>
              </div>
            </div>
          </div>
        </section>
        <?php $this->load->View('Admin/Comman/Footer');?>
      </div>
    </div>
    <!-- JavaScript files-->
    <?php $this->load->View('Admin/Comman/script');?>
  </body>

<!-- Mirrored from demo.bootstrapious.com/dark-admin-premium/1-4-4/tables-datatable.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 06 Feb 2019 03:46:38 GMT -->
</html>
<link rel="stylesheet" href="<?php echo base_url()?>Admin/vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="<?php echo base_url()?>Admin/vendor/font-awesome/css/font-awesome.min.css">
    <!-- Custom Font Icons CSS-->
    <link rel="stylesheet" href="<?php echo base_url()?>Admin/css/font.css">
    <!-- Google fonts - Muli-->
    <link rel="stylesheet" href="<?php echo base_url()?>Admin/https://fonts.googleapis.com/css?family=Muli:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="<?php echo base_url()?>Admin/css/style.default.premium.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your -->
    <link rel="stylesheet" href="<?php echo base_url()?>Admin/css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo base_url()?>Admin/img/favicon.ico">
     <link rel="stylesheet" href="<?php echo base_url()?>Adminvendor/datatables.net-bs4/css/dataTables.bootstrap4.css">
    <link rel="stylesheet" href="<?php echo base_url()?>Adminvendor/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css">


    
<footer class="footer">
          <div class="footer__block block no-margin-bottom">
            <div class="container-fluid text-center">
              <p class="no-margin-bottom" style="padding-left: 40px;">2019 &copy; Fashion Inside Admin </p>
            </div>
          </div>
        </footer>
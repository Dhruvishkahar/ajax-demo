<nav id="sidebar">
        <!-- Sidebar Header-->
        <div class="sidebar-header d-flex align-items-center">
            <div class="avatar"><img src="<?php echo base_url()?>uploads/<?php echo $this->session->userdata('reg_image');?>" alt="" class="img-fluid rounded-circle"  style="height:48px;"></div>
          <div class="title">
            <h1 class="h5"><?php echo $this->session->userdata('reg_uname');?></h1>
            
          </div>
        </div>
        <!-- Sidebar Navidation Menus-->
        <ul class="list-unstyled">
                
                <li><a href="#tablesDropdown" aria-expanded="false" data-toggle="collapse"> <i class="fa fa-plus" style="font-size:24px"></i>  Add-components </a>
                  <ul id="tablesDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo base_url()?>Admin/Category">add category</a></li>
                    <li><a href="<?php echo base_url()?>Admin/SubCategory">add sub-category</a></li>
                    <li><a href="<?php echo base_url()?>Admin/product">add product</a></li>
                  </ul>
                </li>
                <br>
                <li><a href="#chartsDropdown" aria-expanded="false" data-toggle="collapse"><i class="fa fa-grid"></i>Display-components </a>
                  <ul id="chartsDropdown" class="collapse list-unstyled ">
                    <li><a href="<?php echo base_url()?>Admin/showcategory">display category</a></li>
                    <li><a href="<?php echo base_url()?>Admin/ShowSubCategory">display sub-category</a></li>
                     <li><a href="<?php echo base_url()?>Admin/showproduct">display product</a></li>

                  </ul>
                </li><br>
                <li ><a href="<?php echo base_url()?>Admin/order"> <i></i> my-order </a></li><br>
      </nav>
<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fashion Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Home</h2>
          </div>
        </div>
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo base_url()?>Admin/index">Home</a></li>
            <li class="breadcrumb-item active">Add-Category</li>
          </ul>
        </div>
        <section class="no-padding-top" style="margin-left: 150px; margin-top:50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-10" >
                <div class="block">
                  <?php
                    foreach ($sub_cat as $key => $value) {?>
                    <div class="block-body">
                    <form method="POST" action="<?php echo base_url()?>Admin/subcategoryup">
                  
                      <div class="form-group">       
                        <label class="form-control-label" style="color:white;font-weight: bold;"><strong>Sub-id</strong></label>
                       <input id="category" readonly  type="text" name="sub_id" required data-msg="Please enter your category" class="form-control" placeholder="Enter the Category" value="<?php echo $value->sub_id;?>">
                      </div> 

                    <div class="col-mb-12">
                      <label class="form-control-label" style="color: white;font-weight: bold;"><strong>Category</strong></label>
                      <select name="category" class="form-control" required data-msg="Please Choose the Category">
                        <?php

                          foreach ($cat as $res) {?>
                          
                          <option <?php  if($res->cat_id == $value->category_fk) {
                            echo "selected"; } ?> value="<?php echo $res->cat_id;?>" > <?php echo $res->cat_name;?> </option>
                          <?php  }

                        ?>
                      </select>
                    </div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-weight: bold;"><strong>Sub_name</strong></label>
                        <input type="text" name="sub_name" required data-msg="Please Enter the Sub_category" class="form-control" value="<?php echo $value->sub_name;?>">
                        
                      </div>
                          
                              
                             





                      <input type="submit" name="update-Category" value="update-Category" class="btn btn-primary">
                    </form>
                  </div>
                 <?php    }


                  ?>
                </div>
        	</div>
        
</section>
</div>
</div>
            
        
      </div>
        <?php $this->load->View('Admin/Comman/Footer');?>
      </div>
    </div>
     
    <?php $this->load->view('Admin/Comman/script');?>
  </body>
</html>
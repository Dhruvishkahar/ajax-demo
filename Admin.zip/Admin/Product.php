<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fashion Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Home</h2>
          </div>
        </div>
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item active">Add Product</li>
          </ul>
        </div>
        <section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
              
              <div class="col-lg-12" style="padding-left: 250px;margin-top: 05px;padding-right: 200px;margin-left:20px;">
                <div class="block">
                  
                  <div class="block-body">
                    <form method="POST" action="<?php echo base_url()?>Admin/productdata" enctype="multipart/form-data">
                     <div class="form-group" >
                       <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Category</strong></label>
                     </div>
                        <div class="col-sm-12">
                          <select name="category" id="cat_id" class="form-control mb-3 mb-3"  required data-msg="pelase the Choose the category">
                            <option><--Choose Category first-></option>
                              
                              <?php
                                foreach ($cat as $key => $value) {?>
                                 <option value="<?php echo $value->cat_id;?>"><?php echo $value->cat_name;?></option>
                             <?php   }
                              ?>
                          
                          </select>
                        </div>
                        <div class="form-group" >
                       <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Sub-Category</strong></label>
                     </div>
                        <div class="col-sm-12">
                          <select name="sub_category" id="sub_id" class="form-control mb-3 mb-3" required data-msg="pelase the choose the sub_category">
                           <option> <-- select Sub-category first --> </option>
                          <?php
                            foreach ($sub as $key => $value) {?>
                              <option value="<?php echo $value->sub_id;?>"><?php echo $value->sub_name;?></option>
                            <?php }


                          ?>
                          
                          </select>
                        </div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Product-Name</strong></label>
                        <input type="text" name="pro_name" placeholder="Enter the product_name"  id="p_name"  required data-msg="pelase the Enter the product_name" class="form-control">
                        
                      </div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Product-Price</strong></label>
                        <input type="number" price="pro_price" placeholder="Enter the product_price"  required dats-msg="pelase the Enter the product_price" id="p_price" class="form-control" name="pro_price">
                        
                      </div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Product-Descripation</strong></label>
                        <textarea type="text" name="pro_details" descripation="productdescripation" placeholder="Enter the product_descripation" id="
                        p_descripation" required data-msg="pelase the Enter the Product descripation"  class="form-control"></textarea> 
                        
                      </div>
                      <div class="form-group">
                        <label class="form-control-label" style="color: white;font-size: 17px;"><strong>Product-Image</strong></label>
                        <input type="file" image="pro_image" data-msg="pelase the Choose the product_image" required placeholder="Enter the product_image"  id="p_image"  class="form-control" name="pro_image">
                        
                      </div>
                  
                            
                        <input type="submit" name="Addproduct" value="Addproduct" class="btn btn-primary">

                        <?php $this->session->set_flashdata('message', 'Record Inserted');?>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
      <?php $this->load->View('Admin/Comman/Footer');?>
     <?php $this->load->view('Admin/Comman/script');?>
  </body>
  <script type="text/javascript">
  $(document).ready(function(){
    $('#cat_id').change(function(){

 // alert(cat_id);
 var cat_id = $("#cat_id").val();

 //alert(cat_id);

       $.ajax({

       // alert();
       url:"<?php echo base_url() ?>Admin/get_category",
       method:"POST",
       data:{cat_id:cat_id},
       success:function(data){
        //alert(data);
        $('#sub_id').html(data);

       }


       });


});

});


</script>
</html>
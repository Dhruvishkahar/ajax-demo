<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fashion Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Home</h2>
          </div>
        </div>
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item active">Add-Category</li>
          </ul>
        </div>
         <section class="no-padding-top" style="margin-left: 150px; margin-top:50px;">
          <div class="container-fluid">
            <div class="row">
              <div class="col-lg-10" >
                <div class="block">
                  
                  <div class="block-body">
                    <form method="POST" action="<?php echo base_url()?>Admin/addcategorydata">
                  
                      <div class="form-group">       
                        <label class="form-control-label" style="color:white;font-weight: bold;"><strong>Category</strong></label>
                       


                        <input id="category" type="text" name="category" required data-msg="Please enter your category" class="form-control" placeholder="Enter the Category">
                      </div> 



                      <input type="submit" name="Add-Category" value="Add-Category" class="btn btn-primary">
                    </form>
                  </div>
                </div>
        	</div>
        </div>
    </div>
</section>
</div>
</div>
            
        
      </div>
        <?php $this->load->View('Admin/Comman/Footer');?>
      </div>
    </div>
     
    <?php $this->load->view('Admin/Comman/script');?>
  </body>
</html>
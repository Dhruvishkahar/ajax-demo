<!DOCTYPE html>
<html>
<head> 
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Fashion Admin</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <?php $this->load->view('Admin/Comman/css');?>
  </head>
  <body>
    <?php $this->load->view('Admin/Comman/header');?>
    <div class="d-flex align-items-stretch">
      <!-- Sidebar Navigation-->
      <?php $this->load->view('Admin/Comman/navbar');?>
      <!-- Sidebar Navigation end-->
      <div class="page-content">
        <div class="page-header">
          <div class="container-fluid">
            <h2 class="h5 no-margin-bottom">Home</h2>
          </div>
        </div>
        <div class="container-fluid">
          <ul class="breadcrumb">
            <li class="breadcrumb-item"><a href="index">Home</a></li>
            <li class="breadcrumb-item active">Add Sub-Category</li>
          </ul>
        </div>
<section class="no-padding-top">
          <div class="container-fluid">
            <div class="row">
              
              <div class="col-lg-8" style="margin-top: 30px;margin-left:180px;">
                <div class="block">
                  
                  <div class="block-body">
                    <form method="POST" action="<?php echo base_url()?>Admin/addsubcategorydata" onsubmit="return validation()">
                      <div class="form-group row">
                        <label class="col-sm-3 form-control-label" style="color:white;font-weight: bold;"><strong>Sub_category</strong></label></div>

                        <div class="col-sm-12">
                          <!-- <select name="category" id="category" required data-msg="Please enter your add_category" class="form-control mb-3 mb-3"> -->


                            <select id="ecategory" name="category" required data-msg="Please enter your category" class="form-control" placeholder="Enter the add_Category">


                            <option  value="-1"><--Choose Category first-></option>
                              
                              <?php
                                foreach ($cat as $key => $value) {?>
                                 <option value="<?php echo $value->cat_id;?>"><?php echo $value->cat_name;?></option>
                             <?php   }
                              ?>
                          
                          </select>
                        </div>
                      </div>
                  
                      <div class="form-group col-sm-12">       
                        <label class="form-control-label" style="color:white;font-weight: bold;"><strong>Sub-Category</strong></label>
                        <input id="add_category" type="text" name="subcategory" required data-msg="Please enter your add_category" class="form-control" placeholder="Enter the add_Category">
                      </div>
                      <div class="form-group" style="align-items: center; height: 100% width:100%">       
                        <input type="submit" name="AddSubcategory" value="AddSubcategory" class="btn btn-primary">
                      </div>
                    </form>
                  </div>
                </div>
              </div>
</div>
</div>
            
        
      </div>
        <?php $this->load->View('Admin/Comman/Footer');?>
      </div>
    </div>
     
    <?php $this->load->view('Admin/Comman/script');?>
    <script type="text/javascript">
       function  validation()
      
      {
          var category = document.getElementById('ecategory').value;
          //alert(category);

          if(category == '-1')
          {
            //alert('oke');
            var ecategory = document.getElementById('category');
            ecategory.innerHTML="please fill Category First";
            ecategory.style.color = "red";
            return false;
          }

  
         
      }

      
    </script>
  </body>
</html>
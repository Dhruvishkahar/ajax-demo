<!DOCTYPE html>
<html>
<head>
	<title>Success</title>
<style type="text/css">
	body{
		background: black;
	}
	button{
		background:black;
		border-style: none;
		height:50px;

	}
</style>


</head>
<body>
	
	<center><img src="<?php echo base_url()?>User/images/right.gif" style="margin-top:20px;"></center>
	<a href="<?php echo base_url()?>User/index"><button><img src="<?php echo base_url()?>User/images/go.png" style="margin-left: 510px;
    /* margin-top: 150px; */
    margin-top: -120px;
    height: 90px;
    width: 280px;"></button></a>

</body>
</html>
<footer>
		
		<!-- footer third section -->
		<div class="w3l-middlefooter-sec">
			<div class="container py-md-5 py-sm-4 py-3">
				<div class="row footer-info w3-agileits-info">
					<!-- footer categories -->
					<div class="col-md-3 col-sm-6 footer-grids">
						<h3 class="text-white font-weight-bold mb-3">Categories</h3>
						<ul>
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/Shop">Mobiles </a>
							</li>
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/Shop">Computers</a>
							</li>
						</ul>
					</div>
					<!-- //footer categories -->
					<!-- quick links -->
					<div class="col-md-3 col-sm-6 footer-grids mt-sm-0 mt-4">
						<h3 class="text-white font-weight-bold mb-3">Links</h3>
						<ul>
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/index">Home</a>
							</li>
							
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/contact">Contact</a>
							</li>
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/Shop">Shop</a>
							</li>
							<li class="mb-3">
								<a href="<?php echo base_url()?>User/login">Login & signup</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 footer-grids mt-md-0 mt-4">
						<h3 class="text-white font-weight-bold mb-3">Get in Touch</h3>
						<ul>
							<li class="mb-3">
								<i class="fas fa-map-marker"></i>Tops Technologies.</li>
							<li class="mb-3">
								<i class="fas fa-mobile"></i> +91 7046170679 </li>
							
							<li class="mb-3">
								<i class="fas fa-envelope-open"></i>
								<a href="mailto:example@mail.com">dhruvishkahar1996@gmail.com</a>
							</li>
						</ul>
					</div>
					<div class="col-md-3 col-sm-6 footer-grids w3l-agileits mt-md-0 mt-4">
						<!-- newsletter -->
						<h3 class="text-white font-weight-bold mb-3">Maps</h3>
						<p class="mb-3"><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3691.206520994556!2d73.18123331442926!3d22.308027948252835!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x395fcf4bdaf0f89b%3A0xdd295e03d2b284b6!2sTops+Technologies+-+Android+PHP+Java+Training!5e0!3m2!1sen!2sin!4v1551626158294" width="250" height="150" frameborder="0" style="border:0" allowfullscreen></iframe></p>
						
						<div class="footer-grids  w3l-socialmk mt-3">
							<h3 class="text-white font-weight-bold mb-3">Follow Us on</h3>
							<div class="social">
								<ul>
									<li>
										<a class="icon fb" href="#">
											<i class="fab fa-facebook-f"></i>
										</a>
									</li>
									<li>
										<a class="icon tw" href="#">
											<i class="fab fa-twitter"></i>
										</a>
									</li>
									<li>
										<a class="icon gp" href="#">
											<i class="fab fa-google-plus-g"></i>
										</a>
									</li>
								</ul>
							</div>
						</div>
						<!-- //social icons -->
					</div>
				</div>
				<!-- //quick links -->
			</div>
		</div>
		<!-- //footer third section -->

		<!-- footer fourth section -->
		
		<!-- //footer fourth section (text) -->
	</footer>
<div class="copy-right py-3">
		<div class="container">
			<p class="text-center text-white">© 2019 Electronics. All rights reserved | Design by
				<a href="https://www.facebook.com/profile.php?id=100008696652584"> Dhruvish kahar</a>
			</p>
		</div>
	</div>

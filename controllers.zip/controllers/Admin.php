<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->Model('Model');
		$this->load->library("session");
	}
	public function index()
	{

		if (!empty($this->session->userdata('reg_uname'))) 
		{
			$this->load->view('Admin/index');
		}
		else
		{
			redirect('Admin/login');
		 }
	}
	public function login()
	{
		$this->load->view('Admin/login');
	}
	public function auth()
	{

			$data ['reg_uname'] = $this->input->post('username');
			$data ['reg_password'] = md5($this->input->post('password'));
			//print_r($data);
			$login = $this->Model->select_where("reg",$data);
			if(count($login) == 1 )
		{
			$this->load->library('session');
			$sess_array = array();//data member
			foreach ($login as $reg) {
				$sess_array = array(

					"reg_id" => $reg->reg_id,
					"reg_uname"=>$reg->reg_uname,
					"reg_fname"=>$reg->reg_fname,
					"reg_lname"=>$reg->reg_lname,
					"reg_email"=>$reg->reg_email,
					"reg_password"=>$reg->reg_password,
					"reg_image"=>$reg->reg_image
					
				);

				$this->session->set_userdata($sess_array);
				
			}
				//echo $this->session->userdata("reg_uname");
			redirect('Admin/index');

		}
		else
		{

			redirect('Admin/login');
		}

		
	}
	public function register()
	{
		
			$this->load->view('Admin/register');
		
		
	}
	public function adddata()
	{
		$data ['reg_uname'] = $this->input->post('registerUsername');
		$data ['reg_fname'] = $this->input->post('registerfname');
		$data ['reg_lname'] = $this->input->post('registerlname');
		$data ['reg_email'] = $this->input->post('registerEmail');
		$data ['reg_password'] = md5($this->input->post('registerPassword'));
		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|jpeg|png';
        $this->load->library('upload', $config);
 		$this->upload->do_upload('image');
 		$upload_data = $this->upload->data();
 		$data['reg_image'] = $upload_data['file_name'];
		$data ['reg_agree'] = $this->input->post('registerAgree');

		//print_r($data);

		$data['register'] = $this->Model->insert("reg",$data);
		if($data)
		{
			//echo "Record Added";
			redirect('Admin/login');
		}
		else
		{
			echo "Error";
		}

	}
	public function Category()
	{

		$this->load->view('Admin/category');
	}
	public function addcategorydata()
	{
		$data ['cat_name'] = $this->input->post('category');
		print_r($data);
		
		$category = $this->Model->insert("category",$data);
		if($category)
		{
			redirect('Admin/Category');
		}
	}
	public function showcategory()
	{
		$data ['all_category']  = $this->Model->select_all("category");
		//print_r($data);
		$this->load->view('Admin/showcategory',$data);
	}
	public function deletecategory($id)
	{
		$where = array("cat_id"=>$id);
		//print_r($where);
		$delete = $this->Model->delete("category",$where);
		if($delete)
		{
			redirect('Admin/showcategory');
		}
		else
		{
			echo "Error";
		}


	}
	public function updatecategory($id)
	{
		//echo $id;
		$where = array("cat_id"=>$id);
		//print_r($where);

		$data ['edit_data'] = $this->Model->select_where("category",$where);
		
		$this->load->view('Admin/updatecategory',$data);
}
	public function categoryup()
	{
		$id = $this->input->post('cat_id');
		$data ['cat_name'] = $this->input->post('cat_name');
		$where = array("cat_id"=>$id);
		echo "<pre>";
		print_r($data);
		
		$update = $this->Model->update("category",$data,$where);
		//print_r($update);
		//echo "<pre>";
		if($update)
		{
			redirect('Admin/showcategory');
		}
		else{
			echo "
			Error";
		}

	}
	public function SubCategory()
	{
		$data['cat'] = $this->Model->select_all("category");
		$this->load->view('Admin/SubCategory',$data);
	}
	public function addsubcategorydata()
	{
		$data ['category_fk'] = $this->input->post('category');
		$data ['sub_name'] = $this->input->post('subcategory');

		//print_r($data);
		$sub_cat = $this->Model->insert("sub_category",$data);
		if($sub_cat)
		{	
			redirect('Admin/SubCategory');

		}
		else
		{
			echo "Error";
		}
	}
	public function showsubcategory()
	{
		$data ['allsub_category'] = $this->Model->join("sub_category","category","`sub_category`.`category_fk`=`category`.`cat_id`");
		// print_r($data);
		// echo "<pre>";
		$this->load->view('Admin/ShowSubCategory',$data);
	}
	public function deletesubcategory($id)
	{
		$where = array("sub_id"=>$id);
		print_r($where);
		$deletesubcategory = $this->Model->delete("sub_category",$where);
		if($deletesubcategory)
		{
			redirect("Admin/showsubcategory");
		}
		else{
			echo "Error";
		}
	}
	public function updateSubcategory($id)
	{
		//echo $id;
		$where = array("sub_id"=>$id);
		//print_r($where);
		$data ['cat'] =$this->Model->select_all("category");
		//print_r($data);
		$data['sub_cat'] = $this->Model->select_where("sub_category",$where);
		// echo "<pre>";
		// print_r($data['sub_cat']);
	 $this->load->view("Admin/updateSubcategory",$data);



	}
	public function subcategoryup()
	{
		$id = $this->input->post('sub_id');
		$where = array("sub_id"=>$id);
		print_r($where);
		$data ['sub_name'] = $this->input->post('sub_name');
		$data ['category_fk'] = $this->input->post('category');
		print_r($data);
		echo "<pre>";
		$updatesubcategory = $this->Model->update("sub_category",$data,$where);
		if($updatesubcategory)
		{
			redirect('Admin/showsubcategory');
		}
		else
		{
			echo "Error";
		}

	}
	public function get_category()
	{ 
		$cat_id = $this->input->post('cat_id');
		$where  = array("category_fk" => $cat_id);	
		//print_r($cat_id);
		
		$sub = $this->Model->select_where("sub_category",$where);
		//print_r($data['data']);
				foreach ($sub as $key => $value) {
						echo "<option value='$value->sub_id'>$value->sub_name</option>";	
								}				
	}
	public function Product()
	{	
		$data['cat'] = $this->Model->select_all("category");
		$data['sub'] =$this->Model->select_all("sub_category");
		//print_r($data);
		$this->load->view('Admin/Product',$data);
	}
	
	public function productdata()
	{
		$data ['category_fk'] = $this->input->post('category');
		$data ['sub_cat_fk'] = $this->input->post('sub_category');
		$data ['p_name'] = $this->input->post('pro_name');
		$data ['p_price'] = $this->input->post('pro_price');
		$data ['p_details'] = $this->input->post('pro_details');
		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|jpeg|png';
        /*$config['max_size']             = 100;
        $config['max_width']            = 1024;
        $config['max_height']           = 768;*/
        $this->load->library('upload', $config);
 		$this->upload->do_upload('pro_image');
 		$upload_data = $this->upload->data();
 		$data['p_image'] = $upload_data['file_name'];
 		//print_r($data);
 		 $product_data = $this->Model->insert("product",$data);
 		// print_r($product_data);
 		//$mens = $this->Model->insert(,$data);
 		if($product_data)
 		{
 			redirect('Admin/Product');
		}
 		else
 		{
 			echo "Error";
 		}
	}
	public function ShowProduct()
	{
		 $data ['all_product'] = $this->Model->join_three("product","sub_category","category","`product`.`sub_cat_fk`=`sub_category`.`sub_id`","`product`.`category_fk`=`category`.`cat_id`");
		// print_r($data['all_product']);
		 $data ['cat'] = $this->Model->select_all("Category");
		  $data ['sub'] = $this->Model->select_all("sub_category");

		$this->load->view('Admin/ShowProduct',$data);
	}

	
	public function update($id)
	{	
		$where = array("p_id"=>$id);
		$data ['cat'] = $this->Model->select_all("category");
		$data['sub'] = $this->Model->select_all("sub_category");
		$data['all_product'] = $this->Model->select_where("product",$where);
		// echo "<pre>";
		
		// print_r($data);
		$this->load->view("Admin/upproduct",$data);
	}
	public function updatedata()
	{
		$id = $this->input->post('p_id');
		$where = array("p_id"=>$id);
		//print_r($where);
			$data ['p_name'] = $this->input->post('p_name');
			$data ['category_fk'] =$this->input->post('cat_name');
			$data ['sub_cat_fk'] =$this->input->post('sub_name');
			$data ['p_price'] =$this->input->post('p_price');
			$data ['p_details'] =$this->input->post('p_details');

			
			if($_FILES['p_image']['name'])
			{
				$config['upload_path']          = './uploads/';
		        $config['allowed_types']        = 'gif|jpg|png';
		        $this->load->library('upload', $config);
		         if ( ! $this->upload->do_upload('image'))
	                {
	                        echo"error";
                	}
	                else
	                {
                        
                		$upload_data=$this->upload->data();
                        $image=$upload_data['file_name'];
                    }
			}
			else
			{
				$image=$this->input->post('old_image');
			}
			print_r($data);
			// $updatedata  = $this->Model->update("product",$data,$where);
			// 	if($updatedata)
			// 	{
			// 		redirect("Admin/ShowProduct");
			// 	}
			// 	else
			// 	{
			// 		echo "Error";
			// 	}
	}
	public function delete($id)
	{	
		//echo $id;	
		$where =array("p_id"=>$id);
		//print_r($where);
		$delete = $this->Model->delete("product",$where);
		if($delete)
		{	
			redirect('Admin/ShowProduct');
		}
		else
		{
			echo "Error";
		}


	}
	public function order()
	{
		$data['order'] =  $this->Model->join_three("`product_order`","`product`","`reg`","`product_order`.`order_product_fk`=`product`.`p_id`","`product_order`.`order_user_fk`=`reg`.`reg_id`");
		$this->load->view('Admin/product-order',$data);
	}
	public function status($status,$id)
	{
		$where = array("order_id"=>$id);
		//print_r($where);
		if($status == 'pendding')
		{
			$data  = array("order_status" =>'delivered');
			$status = $this->Model->update("product_order",$data,$where);
		}
		else
		{
			$data  = array("order_status" =>'pendding');
			$status = $this->Model->update("product_order",$data,$where);
		}
		if($status){
			redirect("Admin/order");
		}
		else
		{
			echo "check status..";
		}
	}
	public function order_delete($id)
	{
		$where = array("order_id"=>$id);
		print_r($where);
		$order_delete = $this->Model->delete("product_order",$where);
		if($order_delete)
		{
			redirect("Admin/order");
		}
		else
		{
			echo "you are not delete deleted record pelese the choose the delete button. ";
		}
	}
	public function logout()
	{
		$this->load->library("session");
		session_destroy();
		redirect("Admin/login");
	}



}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
	{
		parent::__construct();
		$this->load->Model('Model');
	}
	public function logout()
	{
		$this->load->library('session');
		session_destroy();
		redirect('User/index');
	}
	public function index()
	{
		$data['product'] = $this->Model->select_all("product");
		
		$this->load->view('User/index',$data);
	}
	public function login()
	{
		$this->load->view('User/login');
	}
	public  function auth()
	{
		$uname = $this->input->post('uname');
		$password = $this->input->post('password');
		$where = array("reg_uname"=>$uname,"reg_password"=>$password);

		$login =  $this->Model->select_where("reg",$where);
		// print_r($login);
		// die();

		if(count($login) == 1 )
		{
			$this->load->library('session');
			$sess_array = array();//data member
			foreach ($login as $reg) {
				$sess_array = array(

					"reg_id" => $reg->reg_id,
					"reg_fname"=>$reg->reg_fname,
					"reg_lname"=>$reg->reg_lname,
					"reg_uname"=>$reg->reg_uname,
					"reg_email"=>$reg->reg_email,
					"reg_password"=>$reg->reg_password,
					"reg_image"=>$reg->reg_image
					
				);

				$this->session->set_userdata($sess_array);
				
			}
			//print_r($sess_array);
				//echo $this->session->userdata('reg_image');
			redirect('User/index');

		}
		else
		{

			redirect('User/login');
		}
	}
	public function Register()
	{
		$this->load->view('User/Register');
	}
	public function add_data()
	{
		$data['reg_fname'] = $this->input->post('fname');
		$data['reg_lname'] = $this->input->post('lname');
		$data['reg_uname'] = $this->input->post('uname');
		$data['reg_email'] = $this->input->post('email');
		$data['reg_password'] = $this->input->post('password');


		$config['upload_path']          = './uploads/';
        $config['allowed_types']        = 'gif|jpg|jpeg|png';
        $this->load->library('upload', $config);
 		$this->upload->do_upload('image');
 		$upload_data = $this->upload->data();
 		$data['reg_image'] = $upload_data['file_name'];
		

		$insert = $this->Model->insert("reg",$data);
		if($insert)
		{
			redirect('User/login');
		}
	}
	public function Shop($id = '')
	{
		$data['category'] = $this->Model->select_all("category");

		if($id == '')
		{
			
			$data['p_data'] = $this->Model->select_all("product");
		}
		else
		{
			$where = array("category_fk"=>$id);
		$data['p_data'] = $this->Model->select_where("product",$where);
			
		}

		      $this->load->View('User/product',$data);
	}
	public function single($id)
	{	
		$where = array("p_id"=>$id);
		//$data['category'] = $this->Model->select_all("category");
		$data['product'] = $this->Model->select_where("product",$where);
		//$data['all'] = $this->Model->select_all("product");
		$this->load->View('User/display',$data);
	}
	public function add_to_cart()
	{
		$cart = $this->session->userdata('reg_uname');
		if ($cart == "") {
			redirect('User/login');

		}
		else
	{

		$id = $this->input->post('id');
		$name = $this->input->post('name');
		$price = $this->input->post('price');
		$qty = $this->input->post('qty');
		$image = $this->input->post('image');


		$this->load->library('cart');
		$data = array(

        'id'      => $id,
        'qty'     => $qty,
        'price'   => $price,
        'name'    => $name,
        'image'   => $image
        );

        // print_r($data);
        
         $cart =  $this->cart->insert($data);



         // foreach ($this->cart->contents() as $items) {
         // 	echo "<br>";
         // 	echo $items['id']."<br>";
         // 	echo $items['name']."<br>";
         // 	echo $items['price']."<br>";
         // 	echo $items['qty']."<br>";
         // 	echo $items['subtotal'];
         // }
         // 
         
         if($cart)
         {	
         	redirect('User/display_cart',$cart);
         }
         else
         {
         	echo "Error";
         }
        
	}
}

	public function display_cart()
	{
		
		$this->load->view('User/display_cart');
	}

	public function product_details($id)
	{
		 $where = array("category_fk" => $id,"sub_cat_fk"=>$id);
		 $data['cat_data'] =  $this->Model->select_where("product",$where);
		 $data['category'] = $this->Model->select_all("category");
		 $data['sub_category'] = $this->Model->select_all("sub_category");
		 $data['sub_data'] = $this->Model->select_where("product",$where);
		 
		 $this->load->view('User/Shop_data',$data);

	}

	

	public function save_cart()
	{
		//echo "oke";
		   $payment  = $this->input->post('payment');
		$mobile = $this->input->post('mobile');
		 $address = $this->input->post('address');
		$order_code = "ORD".rand();
        date_default_timezone_set('Asia/Kolkata');
  	    $date = date('Y-M-D H:i:s');
  	    $user_fk = $this->session->userdata('reg_id');

    

  	    foreach ($this->cart->contents() as $items) {
  	    	
  	    	$data = array(

  	    		"order_code" =>  $order_code,
  	    		"order_product_fk" => $items['id'],
  	    		"order_user_fk" =>  $user_fk,
  	    		"order_mobile" => $mobile,
  	    		"order_address" => $address,
  	    		"order_payment" => $payment,
  	    		"order_date" => $date 
  	    		
                );

  	    	echo "<pre>";

  	    	print_r($data);


			 $save_order =  $this->Model->insert("product_order",$data);

  	    	 //print_r($save_order);

          }

            if($save_order)
  	    	 {
  	    	 	$this->cart->destroy();
  	    	 	redirect('User/payment');
  	    	 }
  	    	 else
  	    	 {
  	    	 	echo "Error";
  	    	 }
  	    	 
	}
	public function payment()
	{
		$this->load->view('User/pay_form');
	}
	public function success()
	{
		$this->load->view('User/success');
	}

	public function destroy_cart()
	{
		$this->cart->destroy();
	}
	public function contact()
	{
		$this->load->view('User/contact');
	}
	public function contactdata()
	{
		$data['c_name'] = $this->input->post("name");
		$data['c_email'] = $this->input->post("email");
		$data['c_mobile'] =$this->input->post("mobile");
		$data['c_message'] =$this->input->post("message");

		$data['contact'] = $this->Model->insert("contact",$data);
		if($data)
		{
			redirect("User/contact");
		}
		else
		{
			echo "Error";
		}

	}

}
